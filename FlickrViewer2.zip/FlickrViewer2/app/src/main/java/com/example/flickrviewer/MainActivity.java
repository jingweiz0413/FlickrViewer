package com.example.flickrviewer;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.view.View;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import android.os.AsyncTask;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {
    private AppCompatActivity a;
    private AT at;
    private JSONObject one;
    private JSONObject two;
    private int page;
    private Intent in;
    private boolean create;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        a = this;
        setContentView(R.layout.activity_main);
        at = new AT();
        page = 1;
        at.execute(page);

    }
    @Override
    public void onPause() {
        super.onPause();
        Handler handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                page = 1;
                at = new AT();
                at.execute(page);
            }
        };
        if(create == false) {
            in = new Intent(this, FlickrViewService.class);
            create = true;
        }

        in.putExtra("MESSENGER", new Messenger(handler));
        startService(in);

    }
    @Override
    public void onResume(){
        super.onResume();
        if(create){
            stopService(in);
            create = false;
        }

    }


    public void next(View v){
        page ++;
        at = new AT();
        at.execute(page);

    }

    public void refresh(View v){
        page = 1;
        at = new AT();
        at.execute(page);
    }
    public void previous(View v){
        if(page <= 1)
            return;
        page--;
        at = new AT();
        at.execute(page);

    }
    public void webPage(View v){
        Intent intent = new Intent(this, MainActivityPage.class);
        JSONObject choose;
        if(v.getId() == a.findViewById(R.id.image1).getId())
            choose = one;
        else{
            choose = two;
        }
        try {
            intent.putExtra("OWNER", choose.getString("owner"));
            intent.putExtra("ID", choose.getString("id"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        startActivity(intent);
    }
    private  class AT extends AsyncTask<Integer, Integer, Long> {
        private ImageView im1;
        private ImageView im2;
        private Bitmap bm1;
        private Bitmap bm2;

        protected void onPreExecute(int i) {
        }

        public  Bitmap getBitmapFromURL(String src) {
            try {
                URL url = new URL(src);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream input = connection.getInputStream();
                Bitmap myBitmap = BitmapFactory.decodeStream(input);
                return myBitmap;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
        protected Long doInBackground(Integer... p) {
            int page = p[0];
            try {
                String json = "";
                String line;
                URL url = new URL("https://www.flickr.com/services/rest/?method=flickr.photos.getRecent&api_key=55fe3816cf5b783e1a8edcd18c0aa478&extras=date_taken%2Curl_c%2Ctags%2C+original_format&per_page=2&page="+page+"&format=json&nojsoncallback=1");
                BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
                while ((line = in.readLine()) != null) {
                    json += line;
                }
                in.close();
                JSONObject jsonObject = new JSONObject(json);
                JSONObject photos = jsonObject.getJSONObject("photos");
                JSONArray photo = photos.getJSONArray("photo");
                JSONObject j1 = photo.getJSONObject(0);
                JSONObject j2 = photo.getJSONObject(1);
                one = j1;
                two = j2;
                bm1 = getBitmapFromURL((String) j1.get("url_c"));
                bm2 = getBitmapFromURL((String) j2.get("url_c"));
                im1 = a.findViewById(R.id.image1);
                im2 = a.findViewById(R.id.image2);


            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        private void data(){
            try {
                TextView tv = a.findViewById(R.id.dateText1);
                tv.setText(one.getString("datetaken"));
                tv = a.findViewById(R.id.formatText1);
                tv.setText(one.getString("originalformat"));
                tv = a.findViewById(R.id.tagText1);
                tv.setText(one.getString("tags"));

                tv = a.findViewById(R.id.dateText2);
                tv.setText(two.getString("datetaken"));
                tv = a.findViewById(R.id.formatText2);
                tv.setText(two.getString("originalformat"));
                tv = a.findViewById(R.id.tagText2);
                tv.setText(two.getString("tags"));


            }catch (Exception e){
                e.printStackTrace();
            }
        }

        protected void onProgressUpdate(Integer... progress) {
            /* Run on UI thread, in response to a publishProgress call */
        }

        protected void onPostExecute(Long result) {
            try {
                im1.setImageBitmap(bm1);
                im2.setImageBitmap(bm2);
                data();
            }catch (Exception e){
                e.printStackTrace();
            }

        }
    }
}
