package com.example.flickrviewer;

import android.app.IntentService;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;


public class FlickrViewService extends IntentService {

    Handler handler;

    public FlickrViewService() {
        super("FlickrViewService");
    }

    @Override
    public void onCreate() {
        handler = new Handler();
        super.onCreate();
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Bundle bundle = intent.getExtras();
        if (bundle == null) {
            return;
        }

        Messenger messenger = (Messenger) bundle.get("MESSENGER");

        while (true) {
            Message msg = Message.obtain();
            try {
                messenger.send(msg);
                Thread.sleep(15000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
