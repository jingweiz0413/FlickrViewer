package com.example.flickrviewer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MainActivityPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        String name = getIntent().getStringExtra("OWNER");
        String id = getIntent().getStringExtra("ID");
        WebView wv = findViewById(R.id.web);
        System.out.println(name+"  ..  "+ id);
        wv.loadUrl("https://flickr.com/photos/" + name + "/" + id);
    }
}
